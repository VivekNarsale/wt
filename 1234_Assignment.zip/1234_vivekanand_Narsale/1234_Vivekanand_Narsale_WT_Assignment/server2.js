var express = require("express");
var fs = require("fs");
var path = require("path");
const app = express();
// var getAll = require("./dal");
var sql = require("./mysqlconnect");
//middelware
var staticMiddleware = express.static(path.join(__dirname, "public"));
app.use(staticMiddleware);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

//var credentials = require("./data/credentials.json");
//var customers = require("./data/customers.json");
//var flowers = require("./data/flowers.json");

const filenameForFLower = "./data/flowers.json";
const filenameForCustomers = "./data/customers.json";

app.get("/", (req, res) => {
  res.sendFile("index.html");
});

// customer HTTP routes

app.post("/api/login", (req, res) => {
  var user = req.body;
  let validUser = credentials.find(
    (credential) =>
      credential.username == user.username &&
      credential.password == user.password
  );
  if (validUser !== undefined) {
    console.log("valid");
    res.send("valid user");
  } else {
    console.log("invalid");
    res.send("invalid user");
  }
});

app.post("/api/register", (req, res) => {
  console.log("post is invoked");
  var newUSer = req.body;
  customers.push(newUSer);
  var onWriteFile = function (err) {
    if (err) {
      throw err;
    }
    console.log("new customer added in file");
  };
  fs.writeFile(filenameForCustomers, JSON.stringify(customers), onWriteFile);
  res.send("the new user is registered successfully");
});


//------CRUDE OPERATIONS FOR CUSTOMERS TABLE------------//
app.get("/api/customers", (req, res) => {
  sql.query("select * from customers", function (err, data) {
    if (err) throw err;
    console.log("sending data from db ");
    
    res.send(data);
  });
});

app.get("/api/customer/:id", (req, res) => {
  let id = req.params.id;
  let selectById = "SELECT * FROM customers WHERE id = ?";
  sql.query(selectById, id, function (err, result) {
    if (err) throw err;
    console.log("successfully send res to client by fetching data from db");
    res.send(result);
  });
});

app.put("/api/customers/:id", (req, res) => {
  // update db_name SET
  let id = req.params.id;
  let firstname = req.body.firstname;
  let lastname = req.body.lastname;
  let email = req.body.email;
  let contactnumber = req.body.contactnumber;

  let updateQuery =
    "UPDATE customers SET firstname = ?,lastname = ?, email = ?, contactnumber = ? WHERE id = ?";
  let data = [firstname, lastname, email, contactnumber, id];
  sql.query(updateQuery, data, function (err, data) {
    if (err) throw err;
    res.send(data);
  });
});

app.delete("/api/customers/:id", (req, res) => {
  let id = req.params.id;
  let deleteQuery = "DELETE FROM customers WHERE id =?";
  sql.query(deleteQuery, id, function (err, data) {
    if (err) throw err;
    console.log("successfully deleted " + data.affectedRows);
    res.send(data);
  });
});



// flowers HTTP routes
app.get("/api/flowers", (req, res) => {
  var onFileRead = function (err, data) {
    if (err) {
      throw err;
    }
    console.log("data is availble");
    res.send(JSON.parse(data));
  };
  fs.readFile(filenameForFLower, onFileRead);
});
app.get("/api/flowers/:id", (req, res) => {
  let id = req.params.id;
  let flower = flowers.find((product) => product.id == id);
  res.send(flower);
});

app.post("/api/flowers", (req, res) => {
  var newFlower = req.body;
  flowers.push(newFlower);
  var onWriteFile = function (err) {
    if (err) throw err;
    console.log("flowes addedd to collection in file");
  };
  fs.writeFile(filenameForFLower, JSON.stringify(flowers), onWriteFile);
  res.send("flower are inserted as per client req");
});

app.put("/api/flowers/:id", (req, res) => {
  let id = req.params.id;
  for (let i = 0; i < flowers.length; i++) {
    if (flowers[i].id == id) {
      flowers[i] = req.body;
      break;
    }
  }
  var onWriteFile = function (err) {
    if (err) throw err;
    console.log("content updated successfully");
  };
  fs.writeFile(filenameForFLower, JSON.stringify(flowers), onWriteFile);
  console.log(req.body);
  res.send(req.body);
});

app.delete("/api/flowers/:id", (req, res) => {
  let id = req.params.id;
  let remainFlowers = flowers.filter((product) => product.id != id);
  flowers = remainFlowers;

  var onFileWrite = function (err) {
    if (err) throw err;
    console.log("contents are updated for del req in files");
  };
  fs.writeFile(filenameForFLower, JSON.stringify(flowers), onFileWrite);
  res.send("flower @ " + id + "is deleted successfully");
});

//---------//------CRUDE OPERATIONS FOR ORDERDEATILS TABLE------------//
app.get("/api/orderdetails", (req, res) => {
    sql.query("select * from orderdetails", function (err, data) {
      if (err) throw err;
      console.log("sending data from db ");
      
      res.send(data);
    });
  });

  
  app.get("/api/orderdetail/:orderdetailId", (req, res) => {
    let id = req.params.orderdetailId;
    let selectById = "SELECT * FROM orderdetails WHERE orderdetailId = ?";
    sql.query(selectById, id, function (err, result) {
      if (err) throw err;
      console.log("successfully send res to client by fetching data from db");
      res.send(result);
    });
  });

  //-------------------------------//

  app.put("/api/orderdetail/up/:orderdetailId", (req, res) => {
    // update db_name SET
    let odid = req.params.orderdetailId;
    let oid = req.body.orderid;
    let fid = req.body.flowerid;
    let qnty = req.body.quantity;
  
    let updateQuery =
      "UPDATE orderdetails SET orderid = ?, flowerid = ?,  quantity = ? WHERE  orderdetailId= ?";
    let data = [oid, fid, qnty,odid];
    sql.query(updateQuery, data, function (err, data) {
      if (err) throw err;
      res.send(data);
    });
  });


//remove
app.delete("/api/orderdetail/del/:orderdetailId", (req, res) => {
  let id = req.params.orderdetailId;
  let deleteQuery = "DELETE FROM orderdetails WHERE orderdetailId =?";
  sql.query(deleteQuery, id, function (err, data) {
    if (err) throw err;
    console.log("successfully deleted " + data.affectedRows);
    res.send(data);
  });
});

  //-----------------------------//

  //---------//------CRUDE OPERATIONS FOR ORDERS TABLE------------//

  //
  app.get("/api/orders", (req, res) => {
    sql.query("select * from orders", function (err, data) {
      if (err) throw err;
      console.log("sending data from db ");
      
      res.send(data);
    });
  });

  //
  app.get("/api/order/:orderid", (req, res) => {
    let id = req.params.orderid;
    let selectById = "SELECT * FROM orders WHERE orderid = ?";
    sql.query(selectById, id, function (err, result) {
      if (err) throw err;
      console.log("successfully send res to client by fetching data from db");
      res.send(result);
    });
  });
   
  // specific order  by  specific customer

  app.get("/api/orders/:id", (req, res) => {
    let id = req.params.id;
    let selectOrderOfCust = "SELECT firstname,lastname,orderid,orderdare,amount from orders o inner join customers c on o.id=c.id WHERE c.id = ?";
    sql.query(selectOrderOfCust, id, function (err, result) {
      if (err) throw err;
      console.log("successfully send res to client by fetching data from db");
      res.send(result);
    });
  });


  app.put("/api/order/up/:orderid", (req, res) => {
    // update db_name SET
    let oid = req.params.orderid;
    let odate = req.body.orderdare;
    let cid = req.body.id;
    let amt = req.body.amount;
  
    let updateQuery =
      "UPDATE orders SET orderdare = ?,  id = ?,  amount = ? WHERE  orderid= ?";
    let data = [odate,cid,amt,oid];
    sql.query(updateQuery, data, function (err, data) {
      if (err) throw err;
      res.send(data);
    });

  });

  app.delete("/api/order/del/:orderid", (req, res) => {
    let id = req.params.orderid;
    let deleteQuery = "DELETE FROM orders WHERE orderid=?";
    sql.query(deleteQuery, id, function (err, data) {
      if (err) throw err;
      console.log("successfully deleted " + data.affectedRows);
      res.send(data);
    });
  });

  //
  app.post("/api/add/order",(request,response)=>{
    console.log("POST register is invoked...")
    var data=request.body;
  
  
    var insertQuery="insert into orders values('"+data.orderid+"','"+data.orderdare+"','"+data.id+"','"+data.amount+"')";
      sql.query(insertQuery,function(err,data){
  
          if(err)
          console.log("error is:"+err)
          else
          console.log(data);
      });
  
   // customers.push(newCustomer);
    response.send("order inserted Successful");
  });





app.listen(4040, () => console.log("server is running on port no 4040"));
