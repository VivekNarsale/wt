var mysql=require('mysql');

var connection=mysql.createConnection({

    host:'localhost',
    user:'root',
    password:'root1234',
    database:'tflstore'
});

connection.connect(function(err){

    if(err) throw err;
    else
    console.log("connected to mysql..");

});

module.exports=connection;