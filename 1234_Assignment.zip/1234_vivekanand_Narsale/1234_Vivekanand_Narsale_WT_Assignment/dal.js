var sql=require('./mysqlconnect.js');
//const connection = require('./mysqlconnect');

var getAll=function(){
    var selectAllQuery="select * from customers ";
    sql.query(selectAllQuery,function(err, data){
        if(err){
            console.log("error : "+err);
        }
        else
        {
            console.log(data);
        }
    });
}

var getById=function(id){

    var selectByid="select * from customers where id=1";
    sql.query(selectByid,function(err,data){

        if(err){
            console.log(err)
        }
        else
        console.log(data);

    });
}

var updateName=function(idToUpdate){

    var updateQury="update customers set firstname='sumit' where id="+idToUpdate;
    sql.query(updateQury,function(err,data){
         
        if(err)
        console.log(err)
        else
        console.log(data);
    });
}

//cride api operations with database's data
var insertCustomer=function()
{
    var insertQuery="insert into customers values(3,'seema','sharma','ssharma.@gmail.com','877778888')";
    sql.query(insertQuery,function(err,data){

        if(err)
        console.log("error is:"+err)
        else
        console.log(data);
    });
}

var removeCust=function(idToDeleted){

    var deleteQuery="delete from customers where id="+idToDeleted;
    sql.query(deleteQuery,function(err,data){

        if(err)
        console.log(err)
        else
        console.log(data);

    });

}




//getAll();
//getById(1);
//updateName();
//insertCustomer();
//removeCust(3);
